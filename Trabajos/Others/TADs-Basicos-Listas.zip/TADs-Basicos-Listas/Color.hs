module Color where

data Color = Rojo | Verde | Azul | Negro